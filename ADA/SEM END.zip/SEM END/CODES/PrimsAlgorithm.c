#include <stdio.h>
#include <limits.h>
#include <stdbool.h>

#define MAX 100

int V;

int minKey(int key[], bool mstSet[])
{
    int min = INT_MAX;
    int min_index = -1;

    for(int i=1; i<=V; i++)
    {
        if(!mstSet[i] && key[i] < min)
        {
            min = key[i];
            min_index = i;
        }
    }

    return min_index;
}

void printMST(int parent[], int graph[MAX][MAX])
{
    int totalCost = 0;

    printf("\nEdge \tWeight\n");

    for(int i=2; i<=V; i++)
    {
        printf("%d - %d \t%d\n",
               parent[i], i,
               graph[i][parent[i]]);

        totalCost += graph[i][parent[i]];
    }

    printf("Total Cost of MST = %d\n", totalCost);
}

void primMST(int graph[MAX][MAX])
{
    int parent[MAX];
    int key[MAX];
    bool mstSet[MAX];                                          

    for(int i=1; i<=V; i++)
    {
        key[i] = INT_MAX;
        mstSet[i] = false;
        parent[i] = -1;
    }

    key[1] = 0;

    for(int count=1; count<V; count++)
    {
        int u = minKey(key, mstSet);

        if(u == -1)
        {
            printf("Graph is not connected!\n");
            return;
        }

        mstSet[u] = true;

        for(int j=1; j<=V; j++)
        {
            if(graph[u][j] != 0 && !mstSet[j] && graph[u][j] < key[j])
            {
                parent[j] = u;
                key[j] = graph[u][j];
            }
        }
    }

    printMST(parent, graph);
}

int main()
{
    int graph[MAX][MAX], edges, v, u, cost;

    printf("Enter number of vertices: ");
    scanf("%d", &V);

    printf("Enter number of edges: ");
    scanf("%d", &edges);

    for(int i=1; i<=V; i++)
    {
        for(int j=1; j<=V; j++)
        {
            graph[i][j] = 0;
        }
    }

    printf("Enter %d edges:\n", edges);

    for(int i=1; i<=edges; i++)
    {
        printf("Enter edge: ");
        scanf("%d%d", &u, &v);

        printf("Enter cost: ");
        scanf("%d", &cost);

        graph[u][v] = cost;
        graph[v][u] = cost;
    }

    primMST(graph);

    return 0;
}